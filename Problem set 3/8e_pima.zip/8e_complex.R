#clear the environment
rm(list=ls())

#Import the data
mydata = read.csv("Pid-clean.csv", header = FALSE)
names(mydata) <- c( "V1","V2","V3","V4","V5","V6","V7","V8","V9")
mydata[9][mydata[9]==0] <- 2
clusterable_data = mydata[ -c(9) ]

mean_v1 <- mean(clusterable_data$V1)
sd_v1 <- sd(clusterable_data$V1)
clusterable_data$V1  <- (clusterable_data$V1 - mean_v1) /sd_v1

mean_v2 <- mean(clusterable_data$V2)
sd_v2 <- sd(clusterable_data$V2)
clusterable_data$V2  <- (clusterable_data$V2 - mean_v2) /sd_v2

mean_v3 <- mean(clusterable_data$V3)
sd_v3 <- sd(clusterable_data$V3)
clusterable_data$V3  <- (clusterable_data$V3 - mean_v3) /sd_v3

mean_v4 <- mean(clusterable_data$V4)
sd_v4 <- sd(clusterable_data$V4)
clusterable_data$V4  <- (clusterable_data$V4 - mean_v4) /sd_v4

mean_v5 <- mean(clusterable_data$V5)
sd_v5 <- sd(clusterable_data$V5)
clusterable_data$V5  <- (clusterable_data$V5 - mean_v5) /sd_v5

mean_v6 <- mean(clusterable_data$V6)
sd_v6 <- sd(clusterable_data$V6)
clusterable_data$V6  <- (clusterable_data$V6 - mean_v6) /sd_v6

mean_v7 <- mean(clusterable_data$V7)
sd_v7 <- sd(clusterable_data$V7)
clusterable_data$V7  <- (clusterable_data$V7 - mean_v7) /sd_v7

mean_v8 <- mean(clusterable_data$V8)
sd_v8 <- sd(clusterable_data$V8)
clusterable_data$V8  <- (clusterable_data$V8 - mean_v8) /sd_v8


clusterable_data

min_eps = 0
max_eps = 10
minpts = 1
maxpts = 100
eps = runif(50,min_eps,max_eps)
pts = sample(minpts:maxpts,50)
genes <- array(c(eps,pts),dim = c(50,2))


values_eps = c()
values_ptr = c()
clus = c()
outs = c()
values = c()
iter <- 60
count = 0
while (count < iter){
  i = 1
  while (i < 51){
    set.seed(123)
    db <- fpc::dbscan(clusterable_data, eps = genes[i,1], MinPts = genes[i,2])
    outliers = length(db$cluster[db$cluster==0])/768
    clusters = unique(db$cluster)
    clusters = clusters[clusters != 0]
    cluster_length = length(clusters)
    fitness = c()
    if(cluster_length<2 || cluster_length> 15 || outliers > .1){
      fitness[i] <- (-1*cluster_length*outliers)
    }
    else{
      fitness[i] <- (cluster_length*(1-outliers))
    }
    if(fitness[i]>0){
      outs = append(outs,outliers)
      clus = append(clus,cluster_length)
      values_eps = append(values_eps,genes[i,1])
      values_ptr = append(values_ptr,genes[i,2])
      values = append(values,fitness[i])
    }
    i = i + 1
  }
  
  ordered <- order(fitness)
  population1 = c()
  population2 = c()
  selection = sample(1:40, 20)
  
  i = 1
  while (i <= 40){
    if (i %in%  selection)
    {
      population1<- append(population1,i)
    }
    else{
      population2<- append(population2,i)
    }
    i = i + 1
  }
  
  new_genes <- array(0,dim = c(50,2))
  i = 1
  j = 1
  while (i <= 40){
    new_genes[i,1] <- genes[population1[j],1]
    new_genes[i,2] <- genes[population2[j],2]
    new_genes[i+1,1] <- genes[population2[j],1]
    new_genes[i+1,2] <- genes[population1[j],2] 
    i = i + 2
    j = j + 1
  }
  
  i = 41
  while (i <= 50){
    new_genes[i,1] <- genes[i,1]
    new_genes[i,2] <- genes[i,2]
    i = i + 2
  }
  
  selection = sample(1:50, 10)
  
  i = 1
  while (i <= 10){
    random_eps = runif(1,-1,1)
    random_pts = sample(-1:1, 1)
    new_genes[selection[i],1] = new_genes[selection[i],1] + random_eps
    temp = new_genes[selection[i],2] + random_pts
    #print(length(temp))
    if (temp > 0){
      new_genes[selection[i],2] = temp
    }
    i = i + 1
  }
  
  genes = new_genes
  count = count + 1
}
print(values_eps)
print(values_ptr)
print(clus)
print(outs)
library("fpc")
set.seed(123)
db <- fpc::dbscan(clusterable_data, eps = 2.703986, MinPts = 1)
library("factoextra")
fviz_cluster(db, clusterable_data)
print(db)



purity <- function(a,b,outliers=FALSE) {
  
  cluster_labels <- unique(a)
  class_labels <- unique(b)
  elemets_in_class_by_cluster = matrix(0, nrow = length(cluster_labels), ncol = length(class_labels))
  i = 1
  while (i <= length(a)){
    if(a[i] != 0)
      elemets_in_class_by_cluster[a[i],b[i]] = elemets_in_class_by_cluster[a[i],b[i]] + 1
    i = i + 1
  }
  sum = 0
  i = 1
  while (i <= length(cluster_labels)){
    sum = sum + max(elemets_in_class_by_cluster[i,])
    i = i + 1
  }
  
  purity <- sum/length(a)
  if (outliers==FALSE){
    return (purity)
  }else{
    outlier_number = 0
    n <- table(a)
    outlier_number = n[names(n)==0]
    outlier_percentage = outlier_number / length(a)
    data = c(purity,outlier_percentage)
    return(data)
  }
} 

print(purity(db$cluster,mydata$V9,TRUE))

